fun returnsAnInt(x: Int, y: Int): Int {
    return x * y
}

val f = returnsAnInt(10, 10)
println(f)