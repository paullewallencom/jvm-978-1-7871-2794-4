class EqualsDemo {
    public static void main(String[] args) {
		String foo = "hello";
		String bar = "world";
		if (!foo.equals(bar)) {
			System.out.println("Not equal!");
		}
    }
}