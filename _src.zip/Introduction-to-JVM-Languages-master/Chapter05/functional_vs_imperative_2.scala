class AddDemoFunctional {
    def add(x: Int, y: Int): Int = {
        x + y
    }
}

val b = new AddDemoFunctional
print(b.add(0, 1))
print(b.add(0, 1))