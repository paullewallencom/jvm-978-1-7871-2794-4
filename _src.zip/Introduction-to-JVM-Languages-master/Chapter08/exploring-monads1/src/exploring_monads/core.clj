(ns exploring-monads.core)

(use 'clojure.algo.monads)
 
(defn pretty-msg [msg asterisk-amount]
   (str ""))