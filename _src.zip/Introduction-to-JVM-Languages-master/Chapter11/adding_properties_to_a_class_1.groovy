class Person {
    String name
}

p = new Person()
p.name = "D. Vader"
println(p.name)