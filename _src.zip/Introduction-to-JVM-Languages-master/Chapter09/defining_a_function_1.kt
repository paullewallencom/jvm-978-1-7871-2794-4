fun noReturnValue(x: Int, y: Int): Unit {
}

val f = noReturnValue(1, 2)
println(f)