public class StaticDemo {
    public static String staticVariable = "This is a static variable";
    public String instanceVariable = "This is a class instance variable";
}