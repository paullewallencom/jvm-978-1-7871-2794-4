 var currentTime: java.util.Date? = java.util.Date()
 // Line below will now compile fine
 currentTime = null